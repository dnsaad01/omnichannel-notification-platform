package com.eventflow.ingestion.controller;

import com.eventflow.ingestion.dto.DashboardLogEntry;
import com.eventflow.ingestion.dto.DashboardStatsResponse;
import com.eventflow.ingestion.security.SecurityConfig;
import com.eventflow.ingestion.service.DashboardService;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.context.annotation.Import;
import org.springframework.test.web.servlet.MockMvc;

import java.util.List;

import static org.mockito.Mockito.when;
import static org.springframework.security.test.web.servlet.request.SecurityMockMvcRequestPostProcessors.jwt;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

/**
 * Unlike MonitoringController, /api/dashboard/** is NOT in SecurityConfig's
 * PUBLIC_PATTERNS — every request here needs a Bearer token, which is why
 * every "happy path" test below rides in with .with(jwt()) (from
 * spring-security-test's SecurityMockMvcRequestPostProcessors). The first
 * test proves the inverse: with no token attached at all, the real
 * SecurityConfig filter chain (imported, not mocked) rejects the request
 * before it ever reaches DashboardController.
 */
@WebMvcTest(controllers = DashboardController.class)
@Import(SecurityConfig.class)
class DashboardControllerTest {

  @Autowired
  private MockMvc mockMvc;

  @MockBean
  private DashboardService dashboardService;

  @Test
  void shouldRejectAnUnauthenticatedRequestWithNoBearerToken() throws Exception {
    mockMvc.perform(get("/api/dashboard/stats"))
      .andExpect(status().isUnauthorized());
  }

  @Test
  void shouldReturnStatsWhenAuthenticated() throws Exception {
    when(dashboardService.getStats()).thenReturn(
      DashboardStatsResponse.builder().totalSent("1,234").successRate("92.5%").activeChannels("3").build()
    );

    mockMvc.perform(get("/api/dashboard/stats").with(jwt()))
      .andExpect(status().isOk())
      .andExpect(jsonPath("$.totalSent").value("1,234"))
      .andExpect(jsonPath("$.successRate").value("92.5%"))
      .andExpect(jsonPath("$.activeChannels").value("3"));
  }

  @Test
  void shouldReturnRecentLogsAndDefaultTheLimitTo20WhenNotSpecified() throws Exception {
    when(dashboardService.getRecentLogs(20)).thenReturn(List.of(
      DashboardLogEntry.builder().id("NOTIF-1").user("a@example.com").channel("EMAIL").status("Delivered").time("2 min ago").build()
    ));

    mockMvc.perform(get("/api/dashboard/logs").with(jwt()))
      .andExpect(status().isOk())
      .andExpect(jsonPath("$[0].id").value("NOTIF-1"))
      .andExpect(jsonPath("$[0].status").value("Delivered"));
  }

  @Test
  void shouldForwardAnExplicitLimitQueryParamToTheService() throws Exception {
    when(dashboardService.getRecentLogs(5)).thenReturn(List.of());

    mockMvc.perform(get("/api/dashboard/logs").param("limit", "5").with(jwt()))
      .andExpect(status().isOk())
      .andExpect(jsonPath("$").isArray())
      .andExpect(jsonPath("$").isEmpty());
  }
}
